from flask import Flask, render_template, url_for, request, redirect

app = Flask(__name__)

@app.route("/")
def index():
   return render_template("home.html")

@app.route("/home")
def home():
   return render_template("home.html")

@app.route("/contact")
def about():
   return render_template("product.html")

@app.route("/Oilyskin")
def contact():
   return render_template("product.html")

@app.route("/Dryskin")
def friends():
   return render_template("product.html")

@app.route("/Combination")
def friends():
   return render_template("product.html")

@app.route("/success/<name>")
def success(name):
    return "Welcome %s" % name

@app.route('/login',methods = ['POST', 'GET'])
def login():
    if request.method == 'POST':
        user = request.form['nm']
        return redirect(url_for('success',name = user))
    else:
        user = request.args.get('nm')
        return redirect(url_for('success',name = user))

if __name__ == "__main__":
   app.run()